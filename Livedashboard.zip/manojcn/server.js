const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.static(__dirname + '/'));

// Initialize the count to track the number of active clients
let count = 0;

io.on('connection', (socket) => {
    // Increment count when a new client connects
    count += 1;
    console.log(`New client connected. Active clients: ${count}`);
    
    // Emit the updated count to all connected clients
    io.emit('updateCount', { count });

    // When a client disconnects, decrement the count and emit the updated count
    socket.on('disconnect', () => {
        count -= 1;
        console.log(`Client disconnected. Active clients: ${count}`);
        io.emit('updateCount', { count });
    });
});

server.listen(8080, () => {
    console.log('Server is running on http://127.0.0.1:8080');
});
