const socket = io.connect('http://127.0.0.1:8080');

// Listen for 'updateCount' event from the server and update the count display
socket.on('updateCount', (data) => {
    document.getElementById('countDisplay').innerText = data.count;
});
